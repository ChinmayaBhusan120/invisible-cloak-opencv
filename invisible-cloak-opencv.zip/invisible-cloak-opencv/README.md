# 🧙‍♂️ Invisible Cloak – OpenCV (Python)

A fun computer vision project inspired by **Harry Potter’s Invisible Cloak** — implemented using **OpenCV + Python**.

This project captures the background and makes any **BLUE-colored cloth** appear invisible in real-time!

---

## 🚀 Demo

📌 Works in real time using your laptop webcam.  
📌 Move out of the frame → background captured  
📌 Come back with a BLUE cloth → your body disappears 😄

---

## 📸 How It Works

1. Capture the **background**  
2. Detect BLUE color using **HSV**  
3. Replace the BLUE area with the background  
4. Combine both frames  

---

## 🧪 Run the Project

### Install dependencies
```bash
pip install -r requirements.txt
```

### Run
```bash
python cloak.py
```

---

## 🔧 Controls

| Key | Action |
|-----|--------|
| C   | Re-capture background |
| Q / ESC | Quit program |

---

## 📜 License
Open-source under MIT License.
